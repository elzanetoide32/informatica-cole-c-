/*Ejercicio N°1
gcc tpf-ej2_main.c tpf-ej2_func.c -o ej2.exe
se tiene q linkear el archivo q tiene la funcion y el q lo llama atraves del header
*/
#include <stdio.h>
#include "tpf-ej2_header.h"
int main(){
    main1();
    return 0;
}